package com.google.devrel.samples.ttt;

public class ClientCredentials {
  public static final String AUDIENCE = "server:client_id:your_web_client_id";
}
